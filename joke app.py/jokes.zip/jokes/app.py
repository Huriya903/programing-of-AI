from flask import Flask, render_template, jsonify, request
import requests
import random

app = Flask(__name__)

lame_jokes = [
    {"setup": "Why did the computer go to sleep?", "punchline": "Because it was tired 😐"},
    {"setup": "Why did the student eat his homework?", "punchline": "Because the teacher said it was a piece of cake 😐"},
    {"setup": "Why don't scientists trust atoms?", "punchline": "Because they make up everything 😐"},
    {"setup": "Why did the student eat his homework?", "punchline": "Because the teacher said it was a piece of cake 😐"},
    {"setup": "What will you say when the Italian chef  died?", "punchline": "He pasta-way"},
    {"setup": "Did you hear about the guy who invented the knock-knock joke?", "punchline": "He won the “no-bell” prize"},
    {"setup": "What will you say when the Italian chef  died?", "punchline": "He pasta-way"},
    {"setup": "What will you call a sleeping sause?", "punchline": "soya  sause"},
    {"setup": "What do you call a fake noodle?", "punchline": "An impasta"},
    {"setup": "What kind of tea is hard to swallow?", "punchline": "Reality"},
    {"setup": "The wedding was so beautiful", "punchline": "An impasta"},
    {"setup": "What do you call a fake noodle?", "punchline": "Even the cake was in tiers."},
    {"setup": "I don’t trust stairs", "punchline": "They’re always up to something"}
]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_joke')
def get_joke():
    joke_type = request.args.get("type")

    if joke_type == "funny":
        joke = requests.get("https://official-joke-api.appspot.com/random_joke").json()
    else:
        joke = random.choice(lame_jokes)

    return jsonify(joke)

if __name__ == '__main__':
    app.run(debug=True)